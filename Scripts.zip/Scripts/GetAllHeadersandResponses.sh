#!/bin/bash
mkdir headers
mkdir responsebody
CURRENT_PATH=$(pwd)
for x in $(cat $1)
do
        NAME=$(echo $x | awk -F/ '{print $3}')
        curl -X GET -H "X-Forwarded-For: $2" $x -I > "$CURRENT_PATH/headers/$NAME"
        curl -s -X GET -H "X-Forwarded-For: $2" -L $x > "$CURRENT_PATH/responsebody/$NAME"

        curl -X GET -H "X-Forwarded-Host: $2" $x -I > "$CURRENT_PATH/headers/$NAME"
        curl -s -X GET -H "X-Forwarded-Host: $2" -L $x > "$CURRENT_PATH/responsebody/$NAME"


        curl -X GET -H "X-Original-Forwarded-For: $2" $x -I > "$CURRENT_PATH/headers/$NAME"
        curl -s -X GET -H "X-Original-Forwarded-For: $2" -L $x > "$CURRENT_PATH/responsebody/$NAME"



        curl -X GET -H "X-Real-IP: $2" $x -I > "$CURRENT_PATH/headers/$NAME"
        curl -s -X GET -H "X-Real-IP: $2" -L $x > "$CURRENT_PATH/responsebody/$NAME"



        curl -X GET -H "X-Host: $2" $x -I > "$CURRENT_PATH/headers/$NAME"
        curl -s -X GET -H "X-Host: $2" -L $x > "$CURRENT_PATH/responsebody/$NAME"



        curl -X GET -H "ClientIP: $2" $x -I > "$CURRENT_PATH/headers/$NAME"
        curl -s -X GET -H "ClientIP: $2" -L $x > "$CURRENT_PATH/responsebody/$NAME"


        curl -X GET -H "X-Originating-IP: $2" $x -I > "$CURRENT_PATH/headers/$NAME"
        curl -s -X GET -H "X-Originating-IP: $2" -L $x > "$CURRENT_PATH/responsebody/$NAME"


        curl -X GET -H "Referrer: $2" $x -I > "$CURRENT_PATH/headers/$NAME"
        curl -s -X GET -H "Referrer: $2" -L $x > "$CURRENT_PATH/responsebody/$NAME"











done
