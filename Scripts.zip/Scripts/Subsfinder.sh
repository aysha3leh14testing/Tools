#!/bin/bash

mkdir $1

./assetfinder --subs-only $1 | sort -u > $1/assetf-$1.txt
echo -e "\n"
echo -e "Finished Assetfinder !\n"

./sublist3r -d $1 -o $1/$1-sublist3r.txt

echo -e "Finished Sublist3r !\n"

./subfinder -d $1 -silent > $1/$1-subfinder.txt

echo -e "Finished Subfinder !\n"

python3 github-subdomains.py -d $1 -t dc641b8c8ad4ad046e02af5f70f1c130d971014d >> $1/subss.txt

echo -e "Finished Subdomains Enumeration .. Classifying !\n"
cat $1/$1-sublist3r.txt $1/subss.txt $1/$1-subfinder.txt $1/assetf-$1.txt | grep -v "*" | sort -u | sed '/@/d' | sed '/<BR>/d' | sed '/\_/d' | sed '/*/d' > $1/all-subs.txt

cat $1/all-subs.txt | sort -u | uniq -u | ./httpx -silent > $1/live-Subs.txt

rm $1/$1-sublist3r.txt $1/$1-subfinder.txt $1/assetf-$1.txt $1/subss.txt

cat $1/live-Subs.txt | sed 's/https:\/\///g' | sed 's/http:\/\///g' > $1/live-no-http.txt
