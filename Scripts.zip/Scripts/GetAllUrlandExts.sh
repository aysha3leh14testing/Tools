#!/bin/bash

mkdir extensions
CUR_PATH=$(pwd)

for url in $(cat $1); do
./getallurls -subs $url | grep -v -E "\.png|\.js|\.css|\.woff2|\.jpg|\.ico|\.pdf|\.gif|\.GIF|\.woff|\.ttf|\.eot|\.svg" | sort -u >> results.txt 
done


cat results.txt | grep "\.txt" > "$CUR_PATH/extensions/txt"
cat $CUR_PATH/extensions/txt | grep "robots.txt" > "$CUR_PATH/extensions/robots-txt"
cat $CUR_PATH/extensions/txt | grep -v "robots.txt" > "$CUR_PATH/extensions/txt-no-robots"
rm $CUR_PATH/extensions/txt
cat results.txt | grep "\.ini" > "$CUR_PATH/extensions/ini"
cat results.txt | grep "\.xml" > "$CUR_PATH/extensions/xml"
cat $CUR_PATH/extensions/xml | grep "sitemap" > "$CUR_PATH/extensions/sitemap-xml"
cat $CUR_PATH/extensions/xml | grep -v "sitemap" > "$CUR_PATH/extensions/xml-no-sitemap"
rm $CUR_PATH/extensions/xml
cat results.txt | grep "\.zip" > "$CUR_PATH/extensions/zip"
cat results.txt | grep "\.rar" > "$CUR_PATH/extensions/rar"
cat results.txt | grep "\.asp" > "$CUR_PATH/extensions/asp"
cat results.txt | grep "\.aspx" > "$CUR_PATH/extensions/aspx"
cat results.txt | grep "\.php" > "$CUR_PATH/extensions/php"
cat results.txt | grep "\.jsp" > "$CUR_PATH/extensions/jsp"
cat results.txt | grep -v -E "\.txt|\.ini|\.xml|\.zip|\.rar|\.asp|\.aspx|\.php|\.jsp" > "$CUR_PATH/extensions/other"
cat results.txt | grep "=" > "$CUR_PATH/extensions/params"
rm results.txt