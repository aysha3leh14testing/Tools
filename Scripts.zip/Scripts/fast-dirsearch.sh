#!/bin/bash

python3 ~/Tools/Scripts/dirsearch/dirsearch.py -L $1  -b -e .* -w ~/Tools/Scripts/dirsearch/db/fast.txt --plain-text-report=$1-files.txt

cat $1-files.txt | grep "200" > 200-$1.txt
cat $1-files.txt | grep "301" > 301-$1.txt
cat $1-files.txt | grep "302" > 302-$1.txt
cat $1-files.txt | grep "401" > 401-$1.txt
cat $1-files.txt | grep "403" > 403-$1.txt
rm $1-files.txt